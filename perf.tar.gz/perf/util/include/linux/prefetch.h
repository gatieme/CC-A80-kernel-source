#ifndef PERF_LINUX_PREFETCH_H
#define PERF_LINUX_PREFETCH_H

static inline void prefetch(void *a __attribute__((unused))) { }

#endif
