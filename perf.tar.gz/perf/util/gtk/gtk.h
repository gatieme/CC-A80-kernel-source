#ifndef _PERF_GTK_H_
#define _PERF_GTK_H_ 1

#pragma GCC diagnostic ignored "-Wstrict-prototypes"
#include <gtk/gtk.h>
#pragma GCC diagnostic error "-Wstrict-prototypes"

#endif /* _PERF_GTK_H_ */
